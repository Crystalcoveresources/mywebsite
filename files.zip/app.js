'use strict';
const COMPANY = {
  name: 'Crystal Cove Resources',
  phone: '+91 00000 00000', // TODO: replace with real number
  email: 'info@crystalcoveresources.com', // TODO: replace
  address: 'Gandhidham, Gujarat, India',
};
const CATEGORIES = ['Coal', 'Ferrous Scrap', 'Non-Ferrous Scrap', 'Industrial Scrap'];

const $ = (s) => document.querySelector(s);
const view = $('#view');
let me = null;
let productTimer;

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) =>
  ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const emailOk = (v) => /^\S+@\S+\.\S+$/.test(v || '');
const errs = (...checks) => Object.fromEntries(checks.filter((c) => !c[0]).map(([, k, m]) => [k, m]));
const spinner = '<div class="center"><span class="spin big"></span></div>';
const go = (p) => (location.hash === '#' + p ? router() : (location.hash = p));

async function api(path, { method = 'GET', body } = {}) {
  const res = await fetch(path, {
    method, credentials: 'same-origin',
    headers: body ? { 'Content-Type': 'application/json' } : {},
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Something went wrong. Please try again.');
  return data;
}

function toast(msg, type = 'success') {
  const t = Object.assign(document.createElement('div'), { className: `toast ${type}`, textContent: msg });
  $('#toasts').append(t);
  setTimeout(() => t.remove(), 4000);
}

async function withLoading(btn, fn) {
  const label = btn.textContent;
  btn.disabled = true;
  btn.innerHTML = '<span class="spin"></span> Please wait';
  try { return await fn(); } finally { btn.disabled = false; btn.textContent = label; }
}

function showErrors(form, errors) {
  form.querySelectorAll('[data-err]').forEach((e) => (e.textContent = ''));
  for (const [k, v] of Object.entries(errors)) {
    const el = form.querySelector(`[data-err="${k}"]`);
    if (el) el.textContent = v;
  }
  return Object.keys(errors).length === 0;
}

// ---------- Shell ----------
function renderNav() {
  const links = [['/', 'Home'], ['/products', 'Products'], ['/contact', 'Contact']];
  if (me) links.push(['/dashboard', 'Dashboard']);
  if (me?.role === 'admin') links.push(['/admin', 'Admin']);
  $('#links').innerHTML = links.map(([p, t]) => `<a href="#${p}">${t}</a>`).join('') +
    (me ? '<a href="#" data-logout>Logout</a>'
      : '<a href="#/login">Login</a><a class="btn sm" href="#/register">Register</a>');
}

async function logout() {
  await api('/api/logout', { method: 'POST' }).catch(() => {});
  me = null;
  toast('You have been logged out');
  go('/');
}

document.addEventListener('click', (e) => {
  if (e.target.closest('[data-logout]')) { e.preventDefault(); logout(); }
});

// ---------- Router ----------
const routes = {
  '/': home, '/products': products, '/contact': contact, '/login': login,
  '/register': register, '/dashboard': dashboard, '/admin': admin,
};

async function router() {
  const [path, qs] = (location.hash.slice(1) || '/').split('?');
  const params = new URLSearchParams(qs || '');
  try { me = (await api('/api/me')).user; } catch { me = null; }
  $('#links').classList.remove('open');
  renderNav();
  window.scrollTo({ top: 0 });
  document.querySelectorAll('#links a').forEach((a) =>
    a.classList.toggle('active', a.getAttribute('href') === '#' + path));

  if (path === '/dashboard' && !me) return go('/login');
  if (path === '/admin' && me?.role !== 'admin') return go(me ? '/dashboard' : '/login');
  if ((path === '/login' || path === '/register') && me) return go('/dashboard');

  view.innerHTML = spinner;
  await (routes[path] || notFound)(params);
}

function notFound() {
  view.innerHTML = '<div class="center-text"><h2>Page not found</h2><a class="btn" href="#/">Go home</a></div>';
}

// ---------- Public pages ----------
function home() {
  const features = [
    ['🚢', 'Imported Coal', 'Thermal and industrial coal sourced from reputed international suppliers, graded and sampled.'],
    ['♻️', 'All Scrap Types', 'Ferrous, non-ferrous, copper, aluminium and industrial scrap with fair weighment.'],
    ['⚓', 'Gandhidham Base', 'Based in Gandhidham, Gujarat, close to the Kandla port corridor for quick movement.'],
    ['🤝', 'Transparent Dealing', 'Clear documentation, competitive rates and responsive support on every order.'],
  ];
  view.innerHTML = `
    <section class="hero">
      <span class="tag gold">Gandhidham · Gujarat</span>
      <h1>Trusted Imported Coal &amp; Scrap Trading</h1>
      <p>${COMPANY.name} supplies imported coal alongside every category of ferrous, non-ferrous and industrial scrap.</p>
      <div class="row">
        <a class="btn" href="#/products">Explore products</a>
        <a class="btn ghost" href="#/contact">Request a quote</a>
      </div>
    </section>
    <h2>Why partner with us</h2>
    <p class="lead">Built on quality, transparency and timely delivery.</p>
    <div class="grid">
      ${features.map(([i, t, d]) => `<div class="card"><div class="ico">${i}</div><h3>${t}</h3><p class="muted">${d}</p></div>`).join('')}
    </div>`;
}

async function products(params) {
  view.innerHTML = `
    <h2>Our Products</h2>
    <p class="lead">Search and filter our current inventory.</p>
    <div class="toolbar">
      <input id="q" placeholder="Search coal, scrap, origin…" value="${esc(params.get('q') || '')}">
      <select id="cat">
        <option value="">All categories</option>
        ${CATEGORIES.map((c) => `<option>${esc(c)}</option>`).join('')}
      </select>
    </div>
    <div id="list" class="grid"></div>`;
  const q = $('#q');
  const cat = $('#cat');
  cat.value = params.get('cat') || '';

  const load = async () => {
    $('#list').innerHTML = spinner;
    try {
      const { products } = await api('/api/products?' + new URLSearchParams({ q: q.value, category: cat.value }));
      $('#list').innerHTML = products.length ? products.map((p) => `
        <div class="card">
          <span class="tag">${esc(p.category)}</span>
          <h3>${esc(p.name)}</h3>
          <p class="muted">${esc(p.description)}</p>
          <p><strong>Origin:</strong> ${esc(p.origin || '—')}</p>
          <p><strong>Price:</strong> ${p.price_per_ton ? '₹' + Number(p.price_per_ton).toLocaleString('en-IN') + ' / ton' : 'On request'}</p>
          <a class="btn sm" href="#/contact?product=${encodeURIComponent(p.name)}">Enquire</a>
        </div>`).join('') : '<p class="muted">No products match your search.</p>';
    } catch (err) {
      $('#list').innerHTML = '';
      toast(err.message, 'error');
    }
  };
  q.addEventListener('input', () => { clearTimeout(productTimer); productTimer = setTimeout(load, 300); });
  cat.addEventListener('change', load);
  load();
}

function contact(params) {
  const product = params.get('product') || '';
  view.innerHTML = `
    <h2>Contact Us</h2>
    <p class="lead">Tell us what you need and our team will respond within one business day.</p>
    <div class="split">
      <form id="cf" class="panel" novalidate>
        <label>Name<input name="name" value="${esc(me?.name || '')}"><small class="err" data-err="name"></small></label>
        <label>Email<input name="email" type="email" value="${esc(me?.email || '')}"><small class="err" data-err="email"></small></label>
        <label>Phone<input name="phone" value="${esc(me?.phone || '')}"></label>
        <label>Message<textarea name="message" rows="5">${product ? esc(`I'm interested in: ${product}\n\n`) : ''}</textarea>
          <small class="err" data-err="message"></small></label>
        <button class="btn" type="submit">Send message</button>
      </form>
      <aside class="panel">
        <h3>${COMPANY.name}</h3>
        <p>📍 ${COMPANY.address}</p>
        <p>📞 ${COMPANY.phone}</p>
        <p>✉️ <a href="mailto:${COMPANY.email}">${COMPANY.email}</a></p>
      </aside>
    </div>`;

  $('#cf').addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = e.target;
    const v = Object.fromEntries(new FormData(f));
    const errors = errs(
      [v.name.trim().length > 0, 'name', 'Name is required'],
      [emailOk(v.email.trim()), 'email', 'Enter a valid email'],
      [v.message.trim().length >= 10, 'message', 'Please write at least 10 characters'],
    );
    if (!showErrors(f, errors)) return;
    await withLoading(f.querySelector('button'), async () => {
      try {
        await api('/api/contact', { method: 'POST', body: v });
        f.reset();
        toast('Thanks! We have received your message.');
      } catch (err) { toast(err.message, 'error'); }
    });
  });
}

// ---------- Auth ----------
const authShell = (title, sub, body) =>
  `<div class="auth"><div class="panel"><h2>${title}</h2><p class="lead">${sub}</p>${body}</div></div>`;

function authForm(form, endpoint, rules) {
  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const v = Object.fromEntries(new FormData(form));
    v.email = (v.email || '').trim().toLowerCase();
    if (!showErrors(form, rules(v))) return;
    await withLoading(form.querySelector('button'), async () => {
      try {
        await api(endpoint, { method: 'POST', body: v });
        toast('Welcome!');
        go('/dashboard');
      } catch (err) { toast(err.message, 'error'); }
    });
  });
}

function login() {
  view.innerHTML = authShell('Welcome back', 'Log in to your account', `
    <form id="af" novalidate>
      <label>Email<input name="email" type="email" autocomplete="email"><small class="err" data-err="email"></small></label>
      <label>Password<input name="password" type="password" autocomplete="current-password"><small class="err" data-err="password"></small></label>
      <button class="btn block" type="submit">Log in</button>
      <p class="muted center-text">No account? <a href="#/register">Register</a></p>
    </form>`);
  authForm($('#af'), '/api/login', (v) => errs(
    [emailOk(v.email), 'email', 'Enter a valid email'],
    [!!v.password, 'password', 'Password is required'],
  ));
}

function register() {
  view.innerHTML = authShell('Create account', 'Get quotes and track your enquiries', `
    <form id="af" novalidate>
      <label>Full name<input name="name"><small class="err" data-err="name"></small></label>
      <label>Email<input name="email" type="email" autocomplete="email"><small class="err" data-err="email"></small></label>
      <label>Phone<input name="phone" autocomplete="tel"></label>
      <label>Company<input name="company" autocomplete="organization"></label>
      <label>Password<input name="password" type="password" autocomplete="new-password"><small class="err" data-err="password"></small></label>
      <button class="btn block" type="submit">Create account</button>
      <p class="muted center-text">Already registered? <a href="#/login">Log in</a></p>
    </form>`);
  authForm($('#af'), '/api/register', (v) => errs(
    [v.name.trim().length > 1, 'name', 'Enter your full name'],
    [emailOk(v.email), 'email', 'Enter a valid email'],
    [v.password.length >= 8, 'password', 'Use at least 8 characters'],
  ));
}

// ---------- User dashboard ----------
function dashboard() {
  view.innerHTML = `
    <h2>Hello, ${esc(me.name)} 👋</h2>
    <p class="lead">Manage your profile and account security.</p>
    <div class="split">
      <form id="pf" class="panel" novalidate>
        <h3>Profile</h3>
        <label>Full name<input name="name" value="${esc(me.name)}"><small class="err" data-err="name"></small></label>
        <label>Email<input value="${esc(me.email)}" disabled></label>
        <label>Phone<input name="phone" value="${esc(me.phone || '')}"></label>
        <label>Company<input name="company" value="${esc(me.company || '')}"></label>
        <button class="btn" type="submit">Save profile</button>
      </form>
      <form id="pwf" class="panel" novalidate>
        <h3>Change password</h3>
        <label>Current password<input name="currentPassword" type="password"><small class="err" data-err="currentPassword"></small></label>
        <label>New password<input name="newPassword" type="password"><small class="err" data-err="newPassword"></small></label>
        <button class="btn" type="submit">Update password</button>
      </form>
    </div>
    <button class="btn danger" data-logout>Log out</button>`;

  $('#pf').addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = e.target;
    const v = Object.fromEntries(new FormData(f));
    if (!showErrors(f, errs([v.name.trim().length > 0, 'name', 'Name is required']))) return;
    await withLoading(f.querySelector('button'), async () => {
      try {
        me = (await api('/api/me', { method: 'PUT', body: v })).user;
        renderNav();
        toast('Profile updated');
      } catch (err) { toast(err.message, 'error'); }
    });
  });

  $('#pwf').addEventListener('submit', async (e) => {
    e.preventDefault();
    const f = e.target;
    const v = Object.fromEntries(new FormData(f));
    const errors = errs(
      [!!v.currentPassword, 'currentPassword', 'Enter your current password'],
      [v.newPassword.length >= 8, 'newPassword', 'Use at least 8 characters'],
    );
    if (!showErrors(f, errors)) return;
    await withLoading(f.querySelector('button'), async () => {
      try {
        await api('/api/me/password', { method: 'PUT', body: v });
        f.reset();
        toast('Password updated');
      } catch (err) { toast(err.message, 'error'); }
    });
  });
}

// ---------- Admin console ----------
const TABS = {
  async overview() {
    const s = await api('/api/admin/stats');
    $('#tab').innerHTML = `<div class="grid stats">${[
      ['Users', s.users], ['New users (7 days)', s.newUsers], ['Products', s.products],
      ['Enquiries', s.messages], ['Enquiries (7 days)', s.newMessages],
    ].map(([l, v]) => `<div class="card stat"><span class="muted">${l}</span><strong>${v}</strong></div>`).join('')}</div>`;
  },

  async products() {
    const { products } = await api('/api/admin/products');
    const byId = Object.fromEntries(products.map((p) => [p.id, p]));
    $('#tab').innerHTML = `
      <div class="row between">
        <h3>${products.length} products</h3>
        <button class="btn sm" id="newp">+ Add product</button>
      </div>
      <form id="pform" class="panel hidden" novalidate>
        <input type="hidden" name="id">
        <div class="split">
          <label>Name<input name="name"><small class="err" data-err="name"></small></label>
          <label>Category<select name="category">${CATEGORIES.map((c) => `<option>${c}</option>`).join('')}</select></label>
        </div>
        <div class="split">
          <label>Origin<input name="origin"></label>
          <label>Price per ton (₹, 0 = on request)<input name="price_per_ton" type="number" min="0" step="1" value="0">
            <small class="err" data-err="price_per_ton"></small></label>
        </div>
        <label>Description<textarea name="description" rows="3"></textarea></label>
        <label class="check"><input type="checkbox" name="active" checked> Visible on website</label>
        <div class="row">
          <button class="btn" type="submit">Save</button>
          <button class="btn ghost-d" type="button" id="cancelp">Cancel</button>
        </div>
      </form>
      <div class="table-wrap"><table>
        <thead><tr><th>Name</th><th>Category</th><th>Price</th><th>Status</th><th></th></tr></thead>
        <tbody>${products.map((p) => `
          <tr>
            <td>${esc(p.name)}</td><td>${esc(p.category)}</td>
            <td>${p.price_per_ton ? '₹' + p.price_per_ton : 'On request'}</td>
            <td>${p.active ? '<span class="pill ok">Live</span>' : '<span class="pill">Hidden</span>'}</td>
            <td class="act"><button class="link" data-edit="${p.id}">Edit</button>
              <button class="link danger-t" data-del="${p.id}">Delete</button></td>
          </tr>`).join('') || '<tr><td colspan="5">No products yet</td></tr>'}
        </tbody></table></div>`;

    const f = $('#pform');
    const fld = (n) => f.querySelector(`[name="${n}"]`);
    const openForm = (p = {}) => {
      f.reset();
      fld('id').value = p.id || '';
      fld('name').value = p.name || '';
      fld('category').value = p.category || CATEGORIES[0];
      fld('origin').value = p.origin || '';
      fld('description').value = p.description || '';
      fld('price_per_ton').value = p.price_per_ton || 0;
      fld('active').checked = p.active ?? true;
      f.classList.remove('hidden');
      f.scrollIntoView({ behavior: 'smooth', block: 'center' });
      fld('name').focus();
    };
    $('#newp').onclick = () => openForm();
    $('#cancelp').onclick = () => f.classList.add('hidden');

    f.onsubmit = async (e) => {
      e.preventDefault();
      const v = Object.fromEntries(new FormData(f));
      v.active = fld('active').checked;
      const errors = errs(
        [v.name.trim().length > 0, 'name', 'Name is required'],
        [Number(v.price_per_ton) >= 0, 'price_per_ton', 'Enter a valid price'],
      );
      if (!showErrors(f, errors)) return;
      await withLoading(f.querySelector('button[type=submit]'), async () => {
        try {
          const id = v.id;
          await api(id ? `/api/admin/products/${id}` : '/api/admin/products', { method: id ? 'PUT' : 'POST', body: v });
          toast('Product saved');
          TABS.products();
        } catch (err) { toast(err.message, 'error'); }
      });
    };

    $('#tab').onclick = async (e) => {
      const { edit, del } = e.target.dataset;
      if (edit) openForm(byId[edit]);
      if (del && confirm('Delete this product permanently?')) {
        try {
          await api(`/api/admin/products/${del}`, { method: 'DELETE' });
          toast('Product deleted');
          TABS.products();
        } catch (err) { toast(err.message, 'error'); }
      }
    };
  },

  async messages() {
    const { messages } = await api('/api/admin/messages');
    $('#tab').innerHTML = `<div class="table-wrap"><table>
      <thead><tr><th>Date</th><th>From</th><th>Message</th><th></th></tr></thead>
      <tbody>${messages.map((m) => `
        <tr>
          <td>${new Date(m.created_at.replace(' ', 'T') + 'Z').toLocaleString('en-IN')}</td>
          <td><strong>${esc(m.name)}</strong><br><small>${esc(m.email)} ${esc(m.phone)}</small></td>
          <td class="msg">${esc(m.message)}</td>
          <td class="act"><button class="link danger-t" data-delmsg="${m.id}">Delete</button></td>
        </tr>`).join('') || '<tr><td colspan="4">No enquiries yet</td></tr>'}
      </tbody></table></div>`;
    $('#tab').onclick = async (e) => {
      const id = e.target.dataset.delmsg;
      if (id && confirm('Delete this enquiry?')) {
        try {
          await api(`/api/admin/messages/${id}`, { method: 'DELETE' });
          toast('Enquiry deleted');
          TABS.messages();
        } catch (err) { toast(err.message, 'error'); }
      }
    };
  },

  async users() {
    const { users } = await api('/api/admin/users');
    $('#tab').innerHTML = `<div class="table-wrap"><table>
      <thead><tr><th>Name</th><th>Email</th><th>Company</th><th>Role</th><th></th></tr></thead>
      <tbody>${users.map((u) => `
        <tr>
          <td>${esc(u.name)}</td><td>${esc(u.email)}</td><td>${esc(u.company)}</td>
          <td><span class="pill ${u.role === 'admin' ? 'ok' : ''}">${esc(u.role)}</span></td>
          <td class="act">${u.id === me.id ? '' : `<button class="link danger-t" data-deluser="${u.id}">Delete</button>`}</td>
        </tr>`).join('')}
      </tbody></table></div>`;
    $('#tab').onclick = async (e) => {
      const id = e.target.dataset.deluser;
      if (id && confirm('Delete this user and their sessions?')) {
        try {
          await api(`/api/admin/users/${id}`, { method: 'DELETE' });
          toast('User deleted');
          TABS.users();
        } catch (err) { toast(err.message, 'error'); }
      }
    };
  },
};

function admin() {
  const tabs = ['overview', 'products', 'messages', 'users'];
  view.innerHTML = `
    <h2>Admin Console</h2>
    <p class="lead">Manage products, enquiries and users.</p>
    <div class="tabs">${tabs.map((t) => `<button data-tab="${t}">${t[0].toUpperCase() + t.slice(1)}</button>`).join('')}</div>
    <div id="tab"></div>`;

  const show = async (name) => {
    document.querySelectorAll('[data-tab]').forEach((b) => b.classList.toggle('on', b.dataset.tab === name));
    $('#tab').innerHTML = spinner;
    try { await TABS[name](); } catch (err) { toast(err.message, 'error'); }
  };
  view.querySelectorAll('[data-tab]').forEach((b) => (b.onclick = () => show(b.dataset.tab)));
  show('overview');
}

// ---------- Boot ----------
$('#burger').onclick = () => $('#links').classList.toggle('open');
$('#yr').textContent = new Date().getFullYear();
window.addEventListener('hashchange', router);
router();
