'use strict';
const path = require('path');
const crypto = require('crypto');
const express = require('express');
const Database = require('better-sqlite3');
const rateLimit = require('express-rate-limit');

const PORT = process.env.PORT || 3000;
const IS_PROD = process.env.NODE_ENV === 'production';
const SESSION_MS = 7 * 24 * 60 * 60 * 1000;
const CATEGORIES = ['Coal', 'Ferrous Scrap', 'Non-Ferrous Scrap', 'Industrial Scrap'];

// ---------- Database ----------
const db = new Database(path.join(__dirname, 'crystal_cove.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT UNIQUE NOT NULL,
    phone TEXT DEFAULT '', company TEXT DEFAULT '', password TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user', created_at TEXT DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS sessions (
    token TEXT PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    expires_at INTEGER NOT NULL);
  CREATE TABLE IF NOT EXISTS products (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, category TEXT NOT NULL,
    origin TEXT DEFAULT '', description TEXT DEFAULT '', price_per_ton REAL DEFAULT 0,
    active INTEGER NOT NULL DEFAULT 1, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, email TEXT NOT NULL,
    phone TEXT DEFAULT '', message TEXT NOT NULL, created_at TEXT DEFAULT CURRENT_TIMESTAMP);
`);
db.prepare('DELETE FROM sessions WHERE expires_at < ?').run(Date.now());

// ---------- Helpers ----------
const clean = (v, max = 255) => String(v ?? '').trim().slice(0, max);
const isEmail = (v) => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v);
const hashPassword = (pw) => {
  const salt = crypto.randomBytes(16).toString('hex');
  return salt + ':' + crypto.scryptSync(pw, salt, 64).toString('hex');
};
const checkPassword = (pw, stored) => {
  const [salt, hash] = stored.split(':');
  return crypto.timingSafeEqual(crypto.scryptSync(pw, salt, 64), Buffer.from(hash, 'hex'));
};
const publicUser = (id) =>
  db.prepare('SELECT id, name, email, phone, company, role FROM users WHERE id = ?').get(id);
const productInput = (b) => ({
  name: clean(b.name, 120),
  category: clean(b.category, 50),
  origin: clean(b.origin, 80),
  description: clean(b.description, 1000),
  price: Math.max(0, Number(b.price_per_ton) || 0),
  active: b.active ? 1 : 0,
});

// ---------- App & middleware ----------
const app = express();
if (IS_PROD) app.set('trust proxy', 1);
app.disable('x-powered-by');
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
  next();
});
app.use(express.json({ limit: '100kb' }));
app.use((req, res, next) => { req.body = req.body || {}; next(); });
app.use(express.static(path.join(__dirname, 'public'), { maxAge: '1d' }));

// Session lookup from an HTTP-only cookie (token is 64 hex chars)
app.use((req, res, next) => {
  req.sid = (req.headers.cookie || '').match(/(?:^|;\s*)sid=([a-f0-9]{64})/)?.[1];
  if (req.sid) {
    req.user = db.prepare(`
      SELECT u.id, u.name, u.email, u.phone, u.company, u.role
      FROM sessions s JOIN users u ON u.id = s.user_id
      WHERE s.token = ? AND s.expires_at > ?`).get(req.sid, Date.now());
  }
  next();
});

const requireUser = (req, res, next) =>
  req.user ? next() : res.status(401).json({ error: 'Please log in to continue' });
const requireAdmin = (req, res, next) =>
  req.user?.role === 'admin' ? next() : res.status(403).json({ error: 'Admins only' });

const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000, limit: 20, standardHeaders: true, legacyHeaders: false,
  message: { error: 'Too many attempts. Please try again in 15 minutes.' },
});
const formLimiter = rateLimit({
  windowMs: 60 * 60 * 1000, limit: 10, standardHeaders: true, legacyHeaders: false,
  message: { error: 'Too many messages sent. Please try again later.' },
});

function startSession(res, userId) {
  const token = crypto.randomBytes(32).toString('hex');
  db.prepare('INSERT INTO sessions (token, user_id, expires_at) VALUES (?, ?, ?)')
    .run(token, userId, Date.now() + SESSION_MS);
  res.cookie('sid', token, { httpOnly: true, sameSite: 'lax', secure: IS_PROD, maxAge: SESSION_MS, path: '/' });
}

// ---------- Auth ----------
app.post('/api/register', authLimiter, (req, res) => {
  const name = clean(req.body.name, 100);
  const email = clean(req.body.email, 150).toLowerCase();
  const password = String(req.body.password || '');
  if (!name) return res.status(400).json({ error: 'Name is required' });
  if (!isEmail(email)) return res.status(400).json({ error: 'A valid email is required' });
  if (password.length < 8) return res.status(400).json({ error: 'Password must be at least 8 characters' });
  if (db.prepare('SELECT 1 FROM users WHERE email = ?').get(email))
    return res.status(409).json({ error: 'This email is already registered' });
  const info = db.prepare('INSERT INTO users (name, email, phone, company, password) VALUES (?, ?, ?, ?, ?)')
    .run(name, email, clean(req.body.phone, 20), clean(req.body.company, 150), hashPassword(password));
  startSession(res, info.lastInsertRowid);
  res.status(201).json({ user: publicUser(info.lastInsertRowid) });
});

app.post('/api/login', authLimiter, (req, res) => {
  const email = clean(req.body.email, 150).toLowerCase();
  const row = db.prepare('SELECT id, password FROM users WHERE email = ?').get(email);
  if (!row || !checkPassword(String(req.body.password || ''), row.password))
    return res.status(401).json({ error: 'Invalid email or password' });
  startSession(res, row.id);
  res.json({ user: publicUser(row.id) });
});

app.post('/api/logout', (req, res) => {
  if (req.sid) db.prepare('DELETE FROM sessions WHERE token = ?').run(req.sid);
  res.clearCookie('sid', { path: '/' });
  res.json({ ok: true });
});

app.get('/api/me', requireUser, (req, res) => res.json({ user: publicUser(req.user.id) }));

app.put('/api/me', requireUser, (req, res) => {
  const name = clean(req.body.name, 100);
  if (!name) return res.status(400).json({ error: 'Name is required' });
  db.prepare('UPDATE users SET name = ?, phone = ?, company = ? WHERE id = ?')
    .run(name, clean(req.body.phone, 20), clean(req.body.company, 150), req.user.id);
  res.json({ user: publicUser(req.user.id) });
});

app.put('/api/me/password', requireUser, authLimiter, (req, res) => {
  const row = db.prepare('SELECT password FROM users WHERE id = ?').get(req.user.id);
  const current = String(req.body.currentPassword || '');
  const next = String(req.body.newPassword || '');
  if (!checkPassword(current, row.password)) return res.status(400).json({ error: 'Current password is incorrect' });
  if (next.length < 8) return res.status(400).json({ error: 'New password must be at least 8 characters' });
  db.prepare('UPDATE users SET password = ? WHERE id = ?').run(hashPassword(next), req.user.id);
  db.prepare('DELETE FROM sessions WHERE user_id = ? AND token != ?').run(req.user.id, req.sid);
  res.json({ ok: true });
});

// ---------- Public ----------
app.get('/api/products', (req, res) => {
  const q = `%${clean(req.query.q, 100)}%`;
  const cat = clean(req.query.category, 50);
  const products = db.prepare(`
    SELECT id, name, category, origin, description, price_per_ton FROM products
    WHERE active = 1 AND (name LIKE ? OR origin LIKE ? OR description LIKE ?)
      AND (? = '' OR category = ?)
    ORDER BY name`).all(q, q, q, cat, cat);
  res.json({ products });
});

app.post('/api/contact', formLimiter, (req, res) => {
  const name = clean(req.body.name, 100);
  const email = clean(req.body.email, 150).toLowerCase();
  const phone = clean(req.body.phone, 20);
  const message = clean(req.body.message, 2000);
  if (!name) return res.status(400).json({ error: 'Name is required' });
  if (!isEmail(email)) return res.status(400).json({ error: 'A valid email is required' });
  if (message.length < 10) return res.status(400).json({ error: 'Message must be at least 10 characters' });
  db.prepare('INSERT INTO messages (name, email, phone, message) VALUES (?, ?, ?, ?)').run(name, email, phone, message);
  res.status(201).json({ ok: true });
});

// ---------- Admin ----------
app.use('/api/admin', requireUser, requireAdmin);

app.get('/api/admin/stats', (req, res) => {
  const count = (sql) => db.prepare(sql).get().n;
  const week = "datetime('now', '-7 days')";
  res.json({
    users: count('SELECT COUNT(*) AS n FROM users'),
    newUsers: count(`SELECT COUNT(*) AS n FROM users WHERE created_at >= ${week}`),
    products: count('SELECT COUNT(*) AS n FROM products'),
    messages: count('SELECT COUNT(*) AS n FROM messages'),
    newMessages: count(`SELECT COUNT(*) AS n FROM messages WHERE created_at >= ${week}`),
  });
});

app.get('/api/admin/products', (req, res) =>
  res.json({ products: db.prepare('SELECT * FROM products ORDER BY id DESC').all() }));

app.post('/api/admin/products', (req, res) => {
  const p = productInput(req.body);
  if (!p.name || !CATEGORIES.includes(p.category))
    return res.status(400).json({ error: 'Name and a valid category are required' });
  const info = db.prepare(`INSERT INTO products (name, category, origin, description, price_per_ton, active)
    VALUES (@name, @category, @origin, @description, @price, @active)`).run(p);
  res.status(201).json({ id: info.lastInsertRowid });
});

app.put('/api/admin/products/:id', (req, res) => {
  const p = productInput(req.body);
  if (!p.name || !CATEGORIES.includes(p.category))
    return res.status(400).json({ error: 'Name and a valid category are required' });
  const info = db.prepare(`UPDATE products SET name = @name, category = @category, origin = @origin,
    description = @description, price_per_ton = @price, active = @active WHERE id = @id`)
    .run({ ...p, id: Number(req.params.id) });
  if (!info.changes) return res.status(404).json({ error: 'Product not found' });
  res.json({ ok: true });
});

app.delete('/api/admin/products/:id', (req, res) => {
  const info = db.prepare('DELETE FROM products WHERE id = ?').run(Number(req.params.id));
  if (!info.changes) return res.status(404).json({ error: 'Product not found' });
  res.json({ ok: true });
});

app.get('/api/admin/messages', (req, res) =>
  res.json({ messages: db.prepare('SELECT * FROM messages ORDER BY id DESC LIMIT 200').all() }));

app.delete('/api/admin/messages/:id', (req, res) => {
  db.prepare('DELETE FROM messages WHERE id = ?').run(Number(req.params.id));
  res.json({ ok: true });
});

app.get('/api/admin/users', (req, res) =>
  res.json({ users: db.prepare(`SELECT id, name, email, phone, company, role, created_at
    FROM users ORDER BY id DESC`).all() }));

app.delete('/api/admin/users/:id', (req, res) => {
  const id = Number(req.params.id);
  if (id === req.user.id) return res.status(400).json({ error: 'You cannot delete your own account' });
  db.prepare('DELETE FROM users WHERE id = ?').run(id);
  res.json({ ok: true });
});

// ---------- Fallbacks ----------
app.use('/api', (req, res) => res.status(404).json({ error: 'Not found' }));
app.use((req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.use((err, req, res, next) => {
  if (err.type === 'entity.parse.failed') return res.status(400).json({ error: 'Malformed request' });
  console.error(err);
  res.status(500).json({ error: 'Server error. Please try again.' });
});

// ---------- Seed & start ----------
function seed() {
  if (!db.prepare("SELECT 1 FROM users WHERE role = 'admin'").get()) {
    const email = clean(process.env.ADMIN_EMAIL || 'admin@crystalcove.local', 150).toLowerCase();
    const generated = !process.env.ADMIN_PASSWORD;
    const pw = process.env.ADMIN_PASSWORD || crypto.randomBytes(12).toString('base64url');
    db.prepare("INSERT INTO users (name, email, password, role) VALUES ('Administrator', ?, ?, 'admin')")
      .run(email, hashPassword(pw));
    console.log(`[setup] Admin account created: ${email}`);
    if (generated) console.log(`[setup] Generated admin password (shown once): ${pw}`);
  }
  if (!db.prepare('SELECT 1 FROM products').get()) {
    const sample = [
      ['Indonesian Thermal Coal (5000 GAR)', 'Coal', 'Indonesia', 'Steam coal for power and cement plants, sampled at loading.'],
      ['South African Thermal Coal (5500 GAR)', 'Coal', 'South Africa', 'Low-ash, high-calorific coal suited to boiler and kiln use.'],
      ['Heavy Melting Scrap (HMS-1)', 'Ferrous Scrap', 'India', 'Processed ferrous scrap for steel re-rolling mills.'],
      ['Copper Wire Scrap', 'Non-Ferrous Scrap', 'India', 'Insulated and bare copper scrap, sorted by grade.'],
      ['Aluminium UBC Scrap', 'Non-Ferrous Scrap', 'Domestic', 'Used beverage can scrap, baled and sorted.'],
      ['Industrial Mixed Scrap', 'Industrial Scrap', 'Domestic', 'Mixed industrial scrap collected from plants and workshops.'],
    ];
    const insert = db.prepare('INSERT INTO products (name, category, origin, description) VALUES (?, ?, ?, ?)');
    sample.forEach((row) => insert.run(...row));
  }
}

seed();
app.listen(PORT, () => console.log(`Crystal Cove Resources running on http://localhost:${PORT}`));
